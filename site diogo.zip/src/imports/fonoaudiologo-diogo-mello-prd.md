# PRD - Fonoaudiólogo Diogo Mello | Website Moderno e Profissional

## 1. VISÃO GERAL DO PROJETO

**Objetivo Principal:** Criar um website moderno, profissional e otimizado para conversão que posicione Diogo Mello como referência em aparelhos auditivos no litoral do RS, gerando ligações e formulários de contato.

**Público-Alvo:**
- Pessoas com perda auditiva ou suspeita de problemas auditivos
- Familiares buscando soluções para idosos/parentes
- Pacientes necessitando serviços de ajuste/reparo
- Pessoas em busca de audiometrias (concurso, infantil, comportamental)

**Diferencial Competitivo:**
- Formado pela UFRGS há 13+ anos
- Especialista local com referência no litoral do RS
- Serviços abrangentes e completos
- Parcelamento em até 18x
- Excelentes avaliações (5/5 - 24 reviews)

---

## 2. ARQUITETURA E ESTRUTURA DO SITE

### **2.1 Páginas Principais**

#### **Home (Landing Page)**
- **Hero Section:**
  - Imagem/vídeo profissional com Diogo em consultório
  - Headline: "Recupere Sua Qualidade de Vida - Aparelhos Auditivos & Serviços Especializados"
  - Subheadline: "13 anos de experiência • Referência no litoral do RS"
  - CTA primário: "Agendar Consulta" (WhatsApp)
  - CTA secundário: "Ligar Agora" (tel link)

- **Seção de Destaques:**
  - Cards com benefícios principais
  - Qualificação UFRGS
  - Avaliação 5/5 (24 reviews)
  - Parcelamento em até 18x

- **Seção de Serviços (Preview):**
  - Cards visuais dos principais serviços
  - Links para página de serviços completa

- **Seção de Depoimentos:**
  - Slider com avaliações do Google
  - Destaque para Tatiane Machado e Magda Dias

- **CTA Conversão:**
  - Fale conosco - Formulário ou WhatsApp
  - Horários de funcionamento

---

#### **Sobre Diogo Mello**
- Foto profissional
- Biografia detalhada
- Formação (UFRGS)
- Experiência e especialidades
- Por que escolher Diogo Mello?
- Filosofia de atendimento (qualidade de vida)
- CTA para agendamento

---

#### **Serviços**
Página com card grid/accordion contendo:

1. **Aparelhos Auditivos**
2. **Ajuste de Aparelho Auditivo**
3. **Reparo de Aparelho Auditivo**
4. **Audiometria Tonal e Vocal**
5. **Audiometria para Concurso**
6. **Audiometria Infantil**
7. **Audiometria Comportamental**
8. **Imitanciometria**
9. **Molde para Aparelho Auditivo**
10. **Tampão para Banho**
11. **Atendimento Domiciliar**

Cada serviço com:
- Descrição breve
- Benefícios
- Tempo estimado
- Valor (ou "Solicite orçamento")
- CTA

---

#### **Contato**
- **Formulário de contato:**
  - Nome
  - Email
  - Telefone
  - Assunto/Serviço de interesse
  - Mensagem
  - Checkbox de consentimento LGPD
  - Botão "Enviar"

- **Informações de Contato:**
  - Telefone: (51) 2846-4845
  - WhatsApp: 51 98409-5907
  - Email: [a definir]
  - Endereço: R. Bento Gonçalves, 1367, Centro, Osório - RS, 95520-000

- **Mapa Interativo:**
  - Integração Google Maps
  - Localização exata com rotas

---

#### **Horários**
- Display claro: "Abertos agora" / "Fechados agora"
- Tabela de horários
- Aviso de fechado sábado/domingo

---

### **2.2 Elementos Globais**

**Header/Navbar:**
- Logo + nome "Diogo Mello"
- Menu de navegação (Sobre, Serviços, Contato, Horários)
- CTA flutuante/fixo: "Agendar Agora" (WhatsApp)
- Ícone de telefone para ligação direta
- Responsivo para mobile

**Footer:**
- Links rápidos (Serviços, Sobre, Contato)
- Redes sociais (se aplicável)
- Horários de funcionamento
- Endereço + mapa
- Telefone + WhatsApp
- Copyright
- Aviso de privacidade LGPD

**CTA Flutuante (Mobile):**
- Botão WhatsApp flutuante (ícone verde)
- Botão de ligação (ícone telefone)
- Apenas em mobile/tablet

---

## 3. IDENTIDADE VISUAL

### **3.1 Paleta de Cores**

| Cor | Uso | Código |
|-----|-----|--------|
| **Azul Profissional** | Principal, headers, CTA | #0052CC ou #1E5BA8 |
| **Verde Saúde** | Secundário, destaque | #10A37F (WhatsApp) |
| **Cinza Claro** | Fundo, cards | #F5F5F5 / #EEEEEE |
| **Cinza Escuro** | Texto, títulos | #333333 / #2C3E50 |
| **Branco** | Cards, fundo | #FFFFFF |
| **Verde Escuro** | Hover, accent | #0A7F54 |

### **3.2 Tipografia**

- **Headlines:** Poppins Bold (Google Fonts) - Moderno e confiável
- **Corpo:** Inter ou Roboto Regular - Legível e clean
- **Tamanhos:** 
  - H1: 48px (desktop), 32px (mobile)
  - H2: 36px (desktop), 24px (mobile)
  - Body: 16px

### **3.3 Estilo & Tone**

- **Profissional, acessível e amigável**
- **Confiança através de especialização**
- **Focus em benefícios ao paciente** (qualidade de vida)
- **Urgência moderada** (horários, disponibilidade)

---

## 4. FUNCIONALIDADES E INTEGRAÇÕES

### **4.1 Essenciais**

- ✅ **Formulário de Contato** com validação
- ✅ **Links WhatsApp** (com mensagem pré-preenchida)
- ✅ **Links de Telefone** (tel: protocol)
- ✅ **Google Maps** integrado
- ✅ **Status de Horário** (aberto/fechado em tempo real)
- ✅ **Responsividade** (Mobile-first design)
- ✅ **SEO Básico** (meta tags, estrutura H1-H3)

### **4.2 Desejáveis (Fase 2)**

- 📌 **Sistema de Agendamento** (Calendário integrado)
- 📌 **Integração Google Reviews** (Widget com avaliações)
- 📌 **WhatsApp Bot** (Atendimento automático)
- 📌 **Galeria de fotos** do consultório
- 📌 **Blog** com artigos sobre saúde auditiva
- 📌 **FAQ** com dúvidas comuns

### **4.3 Integrações Técnicas**

- **Formulário → Email + CRM** (Zapier, Make.com)
- **Analytics:** Google Analytics 4
- **Rastreamento de conversão:** Google Tag Manager
- **Verificação Local:** Google Business Profile
- **Open Graph** para compartilhamento social

---

## 5. FLUXO DE CONVERSÃO (CTA)

### **Entrada → Conversão**

```
Visitante
    ↓
[Home - Hero com CTA "Agendar"]
    ↓
Clique em CTA
    ↓
Escolhe:
├─ WhatsApp (redireciona com mensagem pré-preenchida)
├─ Formulário de Contato
└─ Ligar Agora (tel:)
    ↓
Confirmação/Agradecimento
```

### **Mensagens WhatsApp Pré-preenchidas por Página**

- **Home:** "Olá Diogo! Gostaria de agendar uma consulta."
- **Aparelhos Auditivos:** "Tenho interesse em conhecer as opções de aparelhos auditivos. Qual seria o valor?"
- **Audiometria:** "Gostaria de agendar uma audiometria para [tipo]. Qual a disponibilidade?"
- **Reparo:** "Preciso fazer reparo em meu aparelho auditivo. Vocês conseguem resolver meu problema?"

---

## 6. WIREFRAME ESTRUTURAL (HOME)

```
┌─────────────────────────────────────────┐
│           HEADER/NAVBAR                 │
│  Logo | Menu | CTA "Agendar" | Tel      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│      HERO SECTION                       │
│  [Imagem profissional]                  │
│  "Recupere Sua Qualidade de Vida"       │
│  [CTA Primário: Agendar]                │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│    DESTAQUES (3 Cards)                  │
│  [13 anos] [5/5 Reviews] [Parcelamento] │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│    SERVIÇOS (Grid 3-4 Cards)            │
│  [Aparelhos] [Ajuste] [Reparo] [Audio]  │
│  + CTA "Ver Todos"                      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│    SOBRE DIOGO (2 colunas)              │
│  [Foto] | [Biografia + CTA]             │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│    DEPOIMENTOS (Slider)                 │
│  [Review 1] [Review 2] [...navegação]   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│    SEÇÃO CONTATO                        │
│  [Telefone] [WhatsApp] [Mapa]           │
│  [Horários] [Endereço]                  │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│           FOOTER                        │
│  Links | Redes | Copyright | Contato    │
└─────────────────────────────────────────┘
```

---

## 7. MÉTRICAS DE SUCESSO

- **Taxa de Cliques em CTA:** > 5% de cliques em "Agendar/Ligar"
- **Formulários Completos:** > 3 por mês (fase inicial)
- **Mensagens WhatsApp:** > 10 por mês
- **Tempo em Página:** > 1 min 30s
- **Taxa de Bounce:** < 50%
- **Conversão Mobile:** Monitorar separadamente

---

## 8. TECNOLOGIAS RECOMENDADAS

### **Frontend**
- Next.js / React (moderno, SEO-friendly)
- Tailwind CSS (design system clean)
- Framer Motion (animações suaves)

### **Backend/CMS** (Opcional)
- Vercel Deploy (hospedagem)
- Notion / Airtable (base de dados simples)
- Zapier (automação de formulários)

### **Hosting**
- Vercel, Netlify ou AWS

---

## 9. ROADMAP DE IMPLEMENTAÇÃO

### **Fase 1 (MVP - 2-3 semanas)**
- ✅ Home com hero
- ✅ Página de serviços
- ✅ Página sobre
- ✅ Contato (formulário + WhatsApp)
- ✅ Responsividade
- ✅ Deploy

### **Fase 2 (1 mês)**
- 📌 Sistema de agendamento
- 📌 Galeria de fotos
- 📌 Reviews integrados
- 📌 Blog básico

### **Fase 3 (Ongoing)**
- 📌 Otimização SEO
- 📌 A/B testing de CTAs
- 📌 Chatbot WhatsApp

---

## 10. CHECKLIST FINAL

- [ ] Domínio registrado
- [ ] Certificado SSL
- [ ] Google Business Profile atualizado
- [ ] Google Analytics configurado
- [ ] Formulário testado (spam filter)
- [ ] Links WhatsApp testados
- [ ] Responsividade testada (iOS + Android + Desktop)
- [ ] Velocidade otimizada (Lighthouse > 80)
- [ ] LGPD implementado (cookies, política)
- [ ] Backup/Recovery definido

---

Este PRD fornece uma base sólida e detalhada para desenvolvimento de um website profissional e focado em conversão para Diogo Mello. 🎯