import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Sobre } from "./pages/Sobre";
import { Servicos } from "./pages/Servicos";
import { Contato } from "./pages/Contato";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "sobre", Component: Sobre },
      { path: "servicos", Component: Servicos },
      { path: "contato", Component: Contato },
      { path: "*", Component: Home }, // Fallback to home
    ],
  },
]);