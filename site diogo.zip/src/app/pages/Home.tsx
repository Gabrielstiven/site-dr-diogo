import { Link } from "react-router";
import { MessageCircle, PhoneCall, Star, CheckCircle2, ChevronRight, Activity, Ear, Globe } from "lucide-react";
import { motion } from "motion/react";
import imgDoctor from "figma:asset/8f6bbe986994a5355492996825b46201ae580e80.png";
import imgDevices from "figma:asset/3ce7a0e51f2e45ff9de8f1003cf4e27c8e16e1bf.png";

const WHATSAPP_LINK = "https://wa.me/5551984095907?text=Ol%C3%A1%20Doutor!%20Gostaria%20de%20agendar%20uma%20consulta.";

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerChildren = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
};

export function Home() {
  return (
    <div className="w-full bg-[#FAFAFA]">
      
      {/* Hero Section Premium */}
      <section className="relative pt-12 pb-20 lg:pt-24 lg:pb-32 overflow-hidden bg-white">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-1/3 w-[800px] h-[800px] bg-[#f0f5fc] rounded-full blur-[120px] opacity-60 z-0"></div>
        <div className="absolute bottom-0 left-0 translate-y-1/3 -translate-x-1/3 w-[600px] h-[600px] bg-[#10A37F]/10 rounded-full blur-[100px] opacity-60 z-0"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            <motion.div 
              className="lg:col-span-7 text-left pr-0 lg:pr-8"
              initial="hidden"
              animate="visible"
              variants={staggerChildren}
            >
              <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 bg-[#f0f5fc] border border-blue-100 text-[#1E5BA8] text-sm md:text-base font-semibold px-4 py-2 rounded-full mb-8">
                <Globe size={16} />
                <span>Atendimento em Porto Alegre, Osório e Litoral</span>
              </motion.div>
              
              <motion.div variants={fadeInUp}>
                <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-['Poppins'] font-bold text-[#1A1A1A] leading-[1.1] mb-6 tracking-tight">
                  Recupere o prazer de <span className="text-[#1E5BA8] relative whitespace-nowrap">
                    ouvir sua família
                    <svg className="absolute w-full h-3 -bottom-1 left-0 text-[#10A37F] opacity-30" viewBox="0 0 100 10" preserveAspectRatio="none">
                      <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="transparent" strokeLinecap="round" />
                    </svg>
                  </span>
                </h1>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <p className="text-xl md:text-2xl text-gray-600 mb-10 leading-relaxed font-['Inter'] font-light">
                  Tecnologia de ponta em aparelhos auditivos aliada a um cuidado humano. Há <strong className="font-semibold text-gray-800">13 anos</strong> transformando a qualidade de vida na capital e no litoral gaúcho.
                </p>
              </motion.div>
              
              <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4 sm:gap-6">
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noreferrer"
                  className="group flex items-center justify-center gap-3 bg-[#1E5BA8] hover:bg-[#154685] text-white px-8 py-4 md:py-5 rounded-2xl font-semibold transition-all shadow-[0_8px_30px_rgb(30,91,168,0.3)] hover:shadow-[0_8px_30px_rgb(30,91,168,0.5)] text-lg md:text-xl hover:-translate-y-1"
                >
                  <MessageCircle size={24} className="group-hover:scale-110 transition-transform" />
                  Agendar Avaliação
                </a>
                <a
                  href="tel:+555128464845"
                  className="group flex items-center justify-center gap-3 bg-white border border-gray-200 text-gray-700 hover:text-[#1E5BA8] hover:border-[#1E5BA8] hover:bg-blue-50 px-8 py-4 md:py-5 rounded-2xl font-semibold transition-all text-lg md:text-xl"
                >
                  <PhoneCall size={24} className="group-hover:rotate-12 transition-transform" />
                  (51) 2846-4845
                </a>
              </motion.div>

              <motion.div variants={fadeInUp} className="mt-10 flex items-center gap-4 text-sm md:text-base text-gray-500">
                <div className="flex -space-x-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 overflow-hidden shadow-sm">
                      <img src={`https://i.pravatar.cc/100?img=${i + 45}`} alt="Paciente" className="w-full h-full object-cover" />
                    </div>
                  ))}
                  <div className="w-10 h-10 rounded-full border-2 border-white bg-[#f0f5fc] text-[#1E5BA8] flex items-center justify-center font-bold shadow-sm text-xs">
                    +500
                  </div>
                </div>
                <div>
                  <div className="flex text-yellow-400 gap-0.5 mb-0.5">
                    {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                  </div>
                  <span>Pacientes reabilitados no RS</span>
                </div>
              </motion.div>
            </motion.div>

            <motion.div 
              className="lg:col-span-5 relative mt-10 lg:mt-0"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <div className="relative rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.1)]">
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent z-10"></div>
                <img
                  src={imgDoctor}
                  alt="Dr. Diogo Mello em atendimento"
                  className="w-full h-[500px] md:h-[600px] object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 p-8 z-20">
                  <div className="bg-white/95 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/20 inline-block">
                    <p className="font-['Poppins'] font-bold text-gray-900 text-lg">Dr. Diogo Mello</p>
                    <p className="text-[#1E5BA8] font-medium text-sm">Fonoaudiólogo - UFRGS</p>
                  </div>
                </div>
              </div>
              {/* Badge Flutuante */}
              <div className="absolute top-8 -right-4 md:-right-8 bg-white p-4 rounded-2xl shadow-xl border border-gray-100 z-30 flex items-center gap-4 animate-bounce-slow">
                <div className="bg-green-100 p-3 rounded-full text-green-600">
                  <Activity size={24} />
                </div>
                <div>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-0.5">Tecnologia</p>
                  <p className="font-bold text-gray-900 text-sm">Alta Precisão</p>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-white border-t border-gray-100 relative z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-10">
            {[
              { icon: <CheckCircle2 size={32} />, title: "Experiência Comprovada", desc: "13 anos de prática clínica na capital e litoral." },
              { icon: <Star size={32} className="fill-current" />, title: "Nota Máxima no Google", desc: "Reconhecimento 5 estrelas pelos pacientes." },
              { icon: <CheckCircle2 size={32} />, title: "Condições Facilitadas", desc: "Parcelamento em até 18x sem complicações." }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group flex flex-col md:flex-row items-center md:items-start text-center md:text-left gap-4 p-6 rounded-2xl hover:bg-gray-50 transition-colors"
              >
                <div className="text-[#1E5BA8] bg-blue-50 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                  {item.icon}
                </div>
                <div>
                  <h3 className="font-['Poppins'] font-bold text-gray-900 text-xl mb-1">{item.title}</h3>
                  <p className="text-gray-500 text-base">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Showcase Premium */}
      <section className="py-24 bg-[#111827] text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-[#111827] to-[#111827]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-[#10A37F] font-bold tracking-wider uppercase text-sm mb-4 block">Aparelhos Auditivos</span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-['Poppins'] font-bold mb-6 leading-tight">
                Design invisível,<br />som natural.
              </h2>
              <p className="text-xl text-gray-400 mb-10 leading-relaxed font-light">
                Esqueça os aparelhos antigos que apitam. Trabalhamos com tecnologias recarregáveis e modelos tão discretos que ninguém perceberá que você está usando.
              </p>
              
              <ul className="space-y-6 mb-12">
                {[
                  "Conexão Bluetooth direta com celular e TV",
                  "Baterias recarregáveis (sem troca de pilhas)",
                  "Ajuste inteligente de ruído em ambientes cheios"
                ].map((text, i) => (
                  <li key={i} className="flex items-center gap-4 text-lg">
                    <div className="bg-[#1E5BA8]/30 p-2 rounded-full text-blue-400">
                      <CheckCircle2 size={20} />
                    </div>
                    <span className="text-gray-300">{text}</span>
                  </li>
                ))}
              </ul>

              <Link
                to="/servicos"
                className="group inline-flex items-center gap-3 text-white font-semibold text-lg border-b-2 border-[#1E5BA8] pb-1 hover:border-white transition-colors"
              >
                Conhecer todos os modelos
                <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-[#1E5BA8]/20 to-transparent rounded-[3rem] blur-2xl"></div>
              <img
                src={imgDevices}
                alt="Aparelhos auditivos de alta tecnologia"
                className="w-full h-auto rounded-[2rem] shadow-2xl relative z-10 border border-gray-800"
              />
              <div className="absolute -bottom-6 -left-6 bg-[#1E5BA8] p-6 rounded-2xl shadow-xl z-20 max-w-[200px]">
                <Ear size={32} className="text-blue-200 mb-3" />
                <p className="font-semibold text-sm leading-tight">Avaliação completa para testar a tecnologia.</p>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* Testimonials Sofisticado */}
      <section className="py-24 bg-white relative">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-['Poppins'] font-bold text-gray-900 mb-4">A confiança de quem já transformou a própria vida</h2>
            <p className="text-xl text-gray-500">Histórias reais de pacientes atendidos em nossas clínicas.</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[#f0f5fc] rounded-[2rem] p-10 md:p-16 relative"
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[120px] text-white/50 leading-none font-serif opacity-50 select-none pointer-events-none">
              "
            </div>
            
            <div className="flex justify-center text-yellow-400 mb-8 gap-1">
              {[...Array(5)].map((_, i) => <Star key={i} size={28} fill="currentColor" />)}
            </div>
            <p className="text-2xl md:text-3xl text-gray-800 italic mb-10 font-medium leading-relaxed max-w-3xl mx-auto font-['Inter']">
              "O Dr. Diogo tem muita paciência para explicar tudo detalhadamente. Meus aparelhos ficaram perfeitos e a minha qualidade de vida voltou. Recomendo de olhos fechados!"
            </p>
            <div>
              <div className="w-16 h-1 bg-[#1E5BA8] mx-auto mb-6 rounded-full"></div>
              <h4 className="font-['Poppins'] font-bold text-gray-900 text-xl">
                Carlos Ferreira
              </h4>
              <p className="text-gray-500 font-medium">Paciente Avaliado no Google</p>
            </div>
          </motion.div>
        </div>
      </section>

    </div>
  );
}