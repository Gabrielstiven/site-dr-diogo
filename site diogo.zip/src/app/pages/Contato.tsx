import { MapPin, Phone, MessageCircle, Clock, Navigation, Home } from "lucide-react";
import { motion } from "motion/react";
import imgFacade from "figma:asset/cdeb4c2e5e9c8349fa1ff942b567ab19a8744291.png";

export function Contato() {
  return (
    <div className="w-full bg-[#FAFAFA] min-h-screen pt-12 pb-24 lg:pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Elegant Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-24"
        >
          <span className="text-[#10A37F] font-bold tracking-widest uppercase text-sm mb-4 block">Atendimento</span>
          <h1 className="text-4xl lg:text-[4rem] font-['Poppins'] font-bold text-gray-900 mb-6 tracking-tight">
            Estamos aguardando <br/>seu contato.
          </h1>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto font-light leading-relaxed">
            Nossa equipe está preparada para receber você com exclusividade em nossa matriz em Osório, ou através de nosso atendimento personalizado em Porto Alegre e Litoral.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Coluna Esquerda: Fachada e Locais */}
          <motion.div 
            className="lg:col-span-7 space-y-8"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="bg-white p-4 rounded-[2rem] shadow-[0_10px_40px_rgba(0,0,0,0.04)] border border-gray-100">
              <div className="relative rounded-[1.5rem] overflow-hidden group">
                <img
                  src={imgFacade}
                  alt="Fachada Nostra Clínica em Osório"
                  className="w-full h-[300px] md:h-[400px] object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-white">
                  <div>
                    <p className="font-bold text-lg mb-1">Nostra Clínica - Matriz Osório</p>
                    <p className="text-sm text-gray-200">Acesso facilitado no andar térreo</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-md p-3 rounded-xl border border-white/20">
                    <MapPin size={24} />
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Informações adicionais de localização - Matriz */}
              <div className="bg-blue-50/50 rounded-3xl p-8 border border-blue-100 flex flex-col gap-4">
                <div className="text-[#1E5BA8] bg-white p-3 rounded-xl shadow-sm h-fit w-fit">
                  <Navigation size={24} />
                </div>
                <div>
                  <h3 className="font-['Poppins'] font-bold text-gray-900 text-lg mb-2">Clínica Osório</h3>
                  <p className="text-gray-600 font-light leading-relaxed text-sm">
                    Localizada no centro de Osório, com opções de estacionamento nas imediações e entrada totalmente acessível para cadeirantes.
                  </p>
                </div>
              </div>

              {/* Informações - Porto Alegre / Litoral */}
              <div className="bg-[#f0f5fc] rounded-3xl p-8 border border-blue-100 flex flex-col gap-4">
                <div className="text-[#1E5BA8] bg-white p-3 rounded-xl shadow-sm h-fit w-fit">
                  <Home size={24} />
                </div>
                <div>
                  <h3 className="font-['Poppins'] font-bold text-gray-900 text-lg mb-2">Porto Alegre e Litoral</h3>
                  <p className="text-gray-600 font-light leading-relaxed text-sm">
                    Levamos nossa estrutura até você. Realizamos exames e adaptações através de nosso serviço de atendimento domiciliar.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Coluna Direita: Contatos Diretos Premium */}
          <motion.div 
            className="lg:col-span-5"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="bg-white rounded-[2rem] p-8 lg:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.06)] border border-gray-100 sticky top-32">
              <h2 className="text-2xl font-['Poppins'] font-bold text-gray-900 mb-8 border-b border-gray-100 pb-6">
                Canais de Atendimento
              </h2>
              
              <div className="space-y-6">
                
                {/* WhatsApp Button - Primary */}
                <a 
                  href="https://wa.me/5551984095907" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="flex items-center gap-5 p-5 bg-[#10A37F] hover:bg-[#0d8c6b] text-white rounded-2xl transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 group"
                >
                  <div className="bg-white/20 p-3 rounded-xl">
                    <MessageCircle size={28} />
                  </div>
                  <div>
                    <p className="text-sm text-green-100 font-medium mb-0.5">Agendar WhatsApp</p>
                    <p className="text-xl font-bold tracking-wide">(51) 98409-5907</p>
                  </div>
                </a>

                {/* Telefone Button - Secondary */}
                <a 
                  href="tel:+555128464845" 
                  className="flex items-center gap-5 p-5 bg-gray-50 hover:bg-gray-100 text-gray-800 rounded-2xl transition-all border border-gray-200 hover:border-gray-300 group"
                >
                  <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 text-[#1E5BA8]">
                    <Phone size={28} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-medium mb-0.5">Ligar para Recepção</p>
                    <p className="text-xl font-bold tracking-wide">(51) 2846-4845</p>
                  </div>
                </a>

              </div>

              {/* Informações de Endereço em texto */}
              <div className="mt-10 space-y-6 pt-8 border-t border-gray-100">
                <div className="flex gap-4">
                  <MapPin className="text-[#1E5BA8] flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900 text-lg mb-1">Endereço da Matriz</p>
                    <p className="text-gray-600 font-light">Rua Bento Gonçalves, 1367<br/>Centro - Osório, RS<br/>CEP: 95520-000</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Clock className="text-[#1E5BA8] flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900 text-lg mb-1">Horário de Funcionamento</p>
                    <p className="text-gray-600 font-light">
                      Segunda a Sexta-feira<br/>
                      <span className="font-medium text-gray-800">Das 08:00 às 18:00</span>
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </motion.div>

        </div>

      </div>
    </div>
  );
}