import { motion } from "motion/react";
import { CheckCircle2, MessageCircle, ArrowRight } from "lucide-react";
import imgDoctor from "figma:asset/8f6bbe986994a5355492996825b46201ae580e80.png";
import imgClinicInterior from "figma:asset/b952303fb199105e4b98ee4a512e9318d21fed31.png";

const WHATSAPP_LINK = "https://wa.me/5551984095907?text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta%20com%20o%20Dr.%20Diogo.";

export function Sobre() {
  return (
    <div className="w-full bg-[#FAFAFA] pt-12 pb-24 lg:pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Elegant Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 lg:mb-24"
        >
          <span className="text-[#10A37F] font-bold tracking-widest uppercase text-sm mb-4 block">Especialista</span>
          <h1 className="text-4xl lg:text-[4rem] font-['Poppins'] font-bold text-gray-900 mb-6 tracking-tight">
            Dr. Diogo Mello
          </h1>
          <p className="text-xl lg:text-2xl text-gray-500 max-w-3xl mx-auto font-light leading-relaxed">
            Mais de uma década de excelência clínica devolvendo a clareza e a alegria de ouvir.
          </p>
        </motion.div>

        {/* Biografia com Assimetria Elegante */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20 items-center mb-32">
          <motion.div 
            className="lg:col-span-5 relative"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Moldura de fundo deslocada */}
              <div className="absolute inset-0 bg-[#f0f5fc] rounded-[2rem] translate-x-6 translate-y-6 -z-10"></div>
              <img
                src={imgDoctor}
                alt="Dr. Diogo Mello"
                className="w-full h-auto rounded-[2rem] shadow-xl object-cover relative z-10"
              />
            </div>
            {/* Callout box sobreposto */}
            <div className="absolute -bottom-8 -right-4 md:-right-12 bg-white p-6 md:p-8 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-gray-100 z-20 max-w-[280px]">
              <p className="text-4xl font-bold text-[#1E5BA8] font-['Poppins'] mb-1">13+</p>
              <p className="text-gray-600 font-medium leading-tight">Anos de atuação no Rio Grande do Sul</p>
            </div>
          </motion.div>

          <motion.div 
            className="lg:col-span-7"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="text-3xl lg:text-4xl font-['Poppins'] font-bold text-gray-900 mb-8 leading-tight">
              Excelência acadêmica e <br/><span className="text-[#1E5BA8]">atendimento humano.</span>
            </h2>
            
            <div className="space-y-6 text-gray-600 text-lg leading-relaxed font-light mb-10">
              <p>
                Sou fonoaudiólogo formado pela <strong className="text-gray-900 font-medium">Universidade Federal do Rio Grande do Sul (UFRGS)</strong>. Trago a expertise de uma das melhores universidades do país para o coração de Osório, Porto Alegre e todo o Litoral Gaúcho.
              </p>
              <p>
                A reabilitação auditiva não se resume a entregar um aparelho. É um processo de readaptação do cérebro aos sons que foram esquecidos com o tempo. Exige precisão técnica, ajustes milimétricos e, acima de tudo, <strong className="text-gray-900 font-medium">escuta atenta e empatia</strong>.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-6 pt-6 border-t border-gray-200">
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-2 rounded-lg text-[#1E5BA8] mt-1">
                  <CheckCircle2 size={20} />
                </div>
                <p className="font-medium text-gray-800">Avaliação minuciosa e sem pressa</p>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-2 rounded-lg text-[#1E5BA8] mt-1">
                  <CheckCircle2 size={20} />
                </div>
                <p className="font-medium text-gray-800">Acompanhamento contínuo de adaptação</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Estrutura Premium */}
        <div className="mb-32">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              className="order-2 lg:order-1"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-[#1E5BA8] font-bold tracking-widest uppercase text-sm mb-4 block">Nossa Estrutura e Abrangência</span>
              <h2 className="text-3xl lg:text-4xl font-['Poppins'] font-bold text-gray-900 mb-8">
                Um ambiente pensado para o seu conforto.
              </h2>
              <p className="text-lg text-gray-600 mb-10 leading-relaxed font-light">
                Nossa clínica matriz foi projetada para oferecer uma experiência acolhedora e privativa. Contamos com cabine audiométrica de alto padrão e equipamentos calibrados rigorosamente. Além disso, levamos essa mesma excelência para atendimentos em toda a região de Porto Alegre.
              </p>
              
              <ul className="space-y-6 mb-10">
                {[
                  "Equipamentos de última geração para exames",
                  "Matriz em Osório e atendimento em Porto Alegre e Litoral",
                  "Ambiente climatizado, silencioso e acolhedor"
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-4 text-gray-800 font-medium">
                    <span className="w-2 h-2 rounded-full bg-[#10A37F]"></span>
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div 
              className="order-1 lg:order-2"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <img
                src={imgClinicInterior}
                alt="Interior sofisticado do consultório"
                className="w-full h-[400px] lg:h-[500px] rounded-[2rem] shadow-2xl object-cover object-center"
              />
            </motion.div>
          </div>
        </div>

        {/* CTA Sofisticado */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gray-900 rounded-[2rem] p-10 md:p-16 text-center relative overflow-hidden"
        >
          {/* Subtle gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-[#1E5BA8]/20 to-transparent"></div>
          
          <div className="relative z-10">
            <h2 className="text-3xl md:text-4xl font-['Poppins'] font-bold text-white mb-6">
              Agende sua avaliação audiológica
            </h2>
            <p className="text-lg text-gray-300 mb-10 max-w-2xl mx-auto font-light">
              Descubra qual a tecnologia mais adequada para o seu estilo de vida com o acompanhamento de um especialista.
            </p>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center justify-center gap-3 bg-white text-gray-900 px-8 py-4 rounded-full font-bold shadow-lg hover:bg-gray-50 transition-all text-lg"
            >
              Falar com o Doutor
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </motion.div>

      </div>
    </div>
  );
}