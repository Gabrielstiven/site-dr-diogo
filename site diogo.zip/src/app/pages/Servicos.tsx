import { motion } from "motion/react";
import { MessageCircle, Zap, ShieldCheck, Headphones, Sliders, BatteryCharging, ArrowRight, MapPin } from "lucide-react";
import imgPinkApar from "figma:asset/0f15c7fce6fa8c07e996ca5534e1558696456bc9.png";
import imgAccessories from "figma:asset/e78e1b03a2b86c577f3c6ce37bd4db13d1bbb82d.png";

const WHATSAPP_LINK = "https://wa.me/5551984095907?text=Ol%C3%A1!%20Gostaria%20de%20saber%20mais%20sobre%20as%20tecnologias%20dos%20aparelhos.";

export function Servicos() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className="w-full bg-[#FAFAFA] pt-12 pb-24 lg:pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Elegant Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20 lg:mb-32"
        >
          <span className="text-[#10A37F] font-bold tracking-widest uppercase text-sm mb-4 block">Portfólio Clínico</span>
          <h1 className="text-4xl lg:text-[4rem] font-['Poppins'] font-bold text-gray-900 mb-6 tracking-tight">
            Tecnologia e Precisão
          </h1>
          <p className="text-xl lg:text-2xl text-gray-500 max-w-3xl mx-auto font-light leading-relaxed">
            Diagnóstico audiológico completo e adaptação das tecnologias mais avançadas do mundo em reabilitação auditiva.
          </p>
        </motion.div>

        {/* Produto Hero - Aparelhos Recarregáveis */}
        <div className="bg-white rounded-[2rem] shadow-[0_10px_40px_rgba(0,0,0,0.04)] p-8 lg:p-16 mb-24 border border-gray-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-[80px] -z-10"></div>
          
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="inline-flex items-center gap-2 bg-[#f0f5fc] text-[#1E5BA8] text-sm font-semibold px-4 py-2 rounded-full mb-6">
                <BatteryCharging size={16} /> Lançamento
              </span>
              <h2 className="text-3xl lg:text-4xl font-['Poppins'] font-bold text-gray-900 mb-6 leading-tight">
                Praticidade com <br/>tecnologia recarregável.
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed font-light">
                Esqueça a troca constante e as despesas com pilhas. Os novos modelos oferecem autonomia para um dia inteiro de som cristalino com apenas uma carga noturna, em um estojo elegante e portátil.
              </p>
              
              <ul className="space-y-4 mb-10">
                {['Design ultra discreto (RIC)', 'Cancelamento inteligente de ruído', 'Som natural e sem microfonia (apito)'].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-700 font-medium">
                    <Zap size={18} className="text-[#10A37F]" />
                    {item}
                  </li>
                ))}
              </ul>

              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-2 bg-gray-900 text-white px-8 py-4 rounded-full font-semibold hover:bg-[#1E5BA8] transition-all shadow-md"
              >
                Consultar valores
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="aspect-square bg-[#f8fafc] rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-[400px] -z-10"></div>
              <img
                src={imgPinkApar}
                alt="Aparelho auditivo recarregável na cor rosa"
                className="w-full h-auto object-contain drop-shadow-2xl relative z-10 hover:scale-105 transition-transform duration-500"
              />
            </motion.div>
          </div>
        </div>

        {/* Conectividade com Design Assimetrico */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center mb-32">
          <motion.div 
            className="lg:col-span-6 lg:col-start-7 lg:order-2"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl lg:text-4xl font-['Poppins'] font-bold text-gray-900 mb-6">
              Totalmente conectado<br/>ao seu mundo.
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed font-light">
              Transforme seus aparelhos auditivos em fones de ouvido de alta fidelidade. Atenda chamadas telefônicas, ouça mensagens de áudio do WhatsApp e conecte-se à sua TV diretamente. Tudo controlado facilmente por acessórios intuitivos ou pelo seu smartphone.
            </p>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center text-[#1E5BA8] font-bold text-lg hover:text-[#154685] transition-colors group"
            >
              Agendar demonstração da conectividade
              <ArrowRight size={20} className="ml-2 group-hover:translate-x-2 transition-transform" />
            </a>
          </motion.div>

          <motion.div 
            className="lg:col-span-5 lg:col-start-1 lg:order-1"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <img
              src={imgAccessories}
              alt="Acessórios de conectividade e controle remoto para aparelhos auditivos"
              className="w-full h-auto rounded-[2rem] shadow-xl"
            />
          </motion.div>
        </div>

        {/* Serviços Clínicos - Cards Premium */}
        <div className="mb-16">
          <h3 className="text-2xl font-['Poppins'] font-bold text-gray-900 mb-10 text-center">Serviços Clínicos Especializados</h3>
          
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-6"
          >
            {[
              {
                icon: <Headphones size={28} />,
                title: "Audiometria",
                desc: "Avaliação precisa da acuidade auditiva em cabine acústica normatizada, fundamental para diagnóstico e acompanhamento."
              },
              {
                icon: <Sliders size={28} />,
                title: "Ajuste Fino (Mapeamento)",
                desc: "Calibração computadorizada do ganho acústico baseada na sua audiometria para conforto e inteligibilidade máxima."
              },
              {
                icon: <ShieldCheck size={28} />,
                title: "Limpeza e Manutenção",
                desc: "Serviço técnico especializado para remoção de cerume e umidade, garantindo a vida útil do seu equipamento."
              },
              {
                icon: <MapPin size={28} />,
                title: "Atendimento Domiciliar",
                desc: "Levamos nossa estrutura até você. Realizamos exames, testes e adaptações no conforto de sua casa em Porto Alegre e Litoral."
              }
            ].map((srv, idx) => (
              <motion.div 
                key={idx}
                variants={itemVariants}
                className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-all group"
              >
                <div className="w-14 h-14 bg-[#f0f5fc] text-[#1E5BA8] rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#1E5BA8] group-hover:text-white transition-colors duration-300">
                  {srv.icon}
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">{srv.title}</h4>
                <p className="text-gray-500 leading-relaxed text-sm">{srv.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>

      </div>
    </div>
  );
}