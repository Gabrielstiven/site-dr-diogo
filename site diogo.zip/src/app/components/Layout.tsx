import { Link, Outlet, useLocation } from "react-router";
import { Menu, X, Phone, MessageCircle, MapPin, Clock, ArrowRight, Globe } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import clsx from "clsx";

const WHATSAPP_NUMBER = "5551984095907";
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=Ol%C3%A1%20Diogo!%20Gostaria%20de%20agendar%20uma%20consulta.`;

export function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: "Início", path: "/" },
    { name: "Sobre", path: "/sobre" },
    { name: "Serviços", path: "/servicos" },
    { name: "Contato", path: "/contato" },
  ];

  return (
    <div className="flex flex-col min-h-screen font-['Inter'] text-gray-800 bg-white selection:bg-[#1E5BA8] selection:text-white">
      
      {/* Top Bar - Elegant and minimal */}
      <div className="hidden lg:flex bg-gray-900 text-gray-300 py-2.5 px-6 justify-between items-center text-sm font-medium tracking-wide">
        <div className="max-w-7xl mx-auto w-full flex justify-between items-center px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-[#10A37F]" />
            <span>Atendimento: Segunda a Sexta, 08h às 18h</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="tel:+555128464845" className="flex items-center gap-2 hover:text-white transition-colors">
              <Phone size={16} className="text-[#1E5BA8]" />
              <span>(51) 2846-4845</span>
            </a>
            <span className="w-px h-4 bg-gray-700"></span>
            <div className="flex items-center gap-2 text-gray-300">
              <Globe size={16} className="text-[#1E5BA8]" />
              <span>Osório | Porto Alegre | Litoral RS</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header - Sticky with glassmorphism */}
      <header className={clsx(
        "sticky top-0 z-50 transition-all duration-300 bg-white/95 backdrop-blur-md border-b",
        scrolled ? "py-2 shadow-md border-gray-100" : "py-4 md:py-6 border-transparent"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            
            {/* Logo Sophisticated */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-[#1E5BA8] to-[#10A37F] rounded-xl flex items-center justify-center text-white font-['Poppins'] font-bold text-xl md:text-2xl shadow-lg group-hover:shadow-xl transition-all">
                DM
              </div>
              <div className="flex flex-col">
                <span className="font-['Poppins'] font-bold text-xl md:text-2xl text-gray-900 leading-none tracking-tight">
                  Diogo Mello
                </span>
                <span className="text-xs md:text-sm text-[#1E5BA8] font-semibold tracking-widest uppercase mt-0.5">
                  Fonoaudiologia
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={clsx(
                    "text-[15px] font-semibold transition-all relative py-2",
                    location.pathname === link.path
                      ? "text-[#1E5BA8]"
                      : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  {link.name}
                  {location.pathname === link.path && (
                    <motion.div 
                      layoutId="nav-indicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1E5BA8] rounded-full"
                    />
                  )}
                </Link>
              ))}
            </nav>

            {/* CTA Desktop */}
            <div className="hidden lg:flex items-center">
              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noreferrer"
                className="group flex items-center gap-2 bg-gray-900 hover:bg-[#1E5BA8] text-white px-6 py-2.5 rounded-full font-semibold transition-all shadow-md text-sm"
              >
                Agendar Consulta
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden p-2 text-gray-600 hover:text-gray-900 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-white border-t border-gray-100 overflow-hidden shadow-2xl absolute w-full top-full left-0"
            >
              <div className="flex flex-col px-6 py-8 space-y-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={clsx(
                      "text-xl font-semibold p-4 rounded-xl transition-colors",
                      location.pathname === link.path
                        ? "bg-[#f0f5fc] text-[#1E5BA8]"
                        : "text-gray-700 hover:bg-gray-50"
                    )}
                  >
                    {link.name}
                  </Link>
                ))}
                
                <div className="pt-6 mt-4 flex flex-col gap-3">
                  <a
                    href={WHATSAPP_LINK}
                    target="_blank"
                    rel="noreferrer"
                    className="flex justify-center items-center gap-3 bg-[#1E5BA8] text-white px-6 py-4 rounded-xl font-bold text-lg shadow-md"
                  >
                    <MessageCircle size={24} />
                    Falar no WhatsApp
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex flex-col">
        <Outlet />
      </main>

      {/* Elegant Footer */}
      <footer className="bg-gray-50 pt-20 pb-10 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-8 mb-16">
            
            <div className="md:col-span-12 lg:col-span-4">
              <Link to="/" className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-[#1E5BA8] rounded-xl flex items-center justify-center text-white font-['Poppins'] font-bold text-xl shadow-md">
                  DM
                </div>
                <span className="font-['Poppins'] font-bold text-2xl text-gray-900">
                  Diogo Mello
                </span>
              </Link>
              <p className="text-gray-600 leading-relaxed font-medium mb-6 pr-4">
                Especialista em reabilitação auditiva. Tecnologia invisível e atendimento humanizado para você voltar a ouvir com perfeição.
              </p>
            </div>

            <div className="md:col-span-6 lg:col-span-3 lg:col-start-6">
              <h3 className="font-['Poppins'] font-bold text-gray-900 text-lg mb-6">Navegação</h3>
              <ul className="space-y-4 font-medium text-gray-600">
                <li><Link to="/" className="hover:text-[#1E5BA8] transition-colors">Início</Link></li>
                <li><Link to="/sobre" className="hover:text-[#1E5BA8] transition-colors">O Especialista</Link></li>
                <li><Link to="/servicos" className="hover:text-[#1E5BA8] transition-colors">Nossos Aparelhos</Link></li>
                <li><Link to="/contato" className="hover:text-[#1E5BA8] transition-colors">Como Chegar</Link></li>
              </ul>
            </div>

            <div className="md:col-span-6 lg:col-span-4">
              <h3 className="font-['Poppins'] font-bold text-gray-900 text-lg mb-6">Contato e Abrangência</h3>
              <ul className="space-y-5 font-medium">
                <li>
                  <a href="tel:+555128464845" className="flex items-start gap-4 text-gray-600 hover:text-[#1E5BA8] transition-colors group">
                    <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-100 group-hover:border-[#1E5BA8] transition-colors">
                      <Phone size={20} className="text-[#1E5BA8]" />
                    </div>
                    <div className="mt-1">(51) 2846-4845</div>
                  </a>
                </li>
                <li>
                  <div className="flex items-start gap-4 text-gray-600">
                    <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-100">
                      <Globe size={20} className="text-[#1E5BA8]" />
                    </div>
                    <div className="mt-1 leading-relaxed">
                      <strong className="text-gray-800">Matriz:</strong> Rua Bento Gonçalves, 1367<br/>
                      Centro, Osório - RS<br/>
                      <span className="block mt-2 text-sm text-[#1E5BA8] bg-blue-50 py-1.5 px-3 rounded-lg border border-blue-100">
                        Atendimento presencial e domiciliar também em Porto Alegre e Litoral Gaúcho.
                      </span>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500 font-medium">
            <p>&copy; {new Date().getFullYear()} Diogo Mello Fonoaudiólogo. Todos os direitos reservados.</p>
            <p>Atendimento conforme normas da LGPD.</p>
          </div>
        </div>
      </footer>

      {/* Floating CTA - Modern and subtle */}
      <a
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 lg:bottom-8 lg:right-8 bg-[#10A37F] text-white p-4 rounded-full shadow-[0_8px_30px_rgb(16,163,127,0.3)] hover:shadow-[0_8px_30px_rgb(16,163,127,0.5)] hover:-translate-y-1 hover:scale-105 transition-all z-50 flex items-center justify-center group"
        aria-label="Falar no WhatsApp"
      >
        <MessageCircle size={32} />
        {/* Tooltip that slides out smoothly on hover */}
        <div className="absolute right-full mr-4 bg-gray-900 text-white text-sm font-semibold py-2 px-4 rounded-xl opacity-0 translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all pointer-events-none whitespace-nowrap hidden md:block shadow-xl">
          Posso ajudar?
          <div className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-3 h-3 bg-gray-900 rotate-45"></div>
        </div>
      </a>
    </div>
  );
}