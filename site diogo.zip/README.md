
  # Criar site baseado em referência

  This is a code bundle for Criar site baseado em referência. The original project is available at https://www.figma.com/design/w2Vojj6WDgxejroDdWqzEY/Criar-site-baseado-em-refer%C3%AAncia.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  